import fs from 'fs';
import path from 'path';

const DATA_FILE = path.join(process.cwd(), 'resumes.json');

function readData() {
  try {
    if (!fs.existsSync(DATA_FILE)) return [];
    const raw = fs.readFileSync(DATA_FILE, 'utf8');
    return JSON.parse(raw || '[]');
  } catch (e) {
    return [];
  }
}
function writeData(arr) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(arr, null, 2), 'utf8');
}

export const saveResume = async (req, res) => {
  try {
    const data = req.body;
    const all = readData();
    const id = Date.now().toString();
    const item = { id, ...data, createdAt: new Date().toISOString() };
    all.unshift(item);
    writeData(all);
    return res.json({ message: 'Saved locally', resume: item });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
};

export const getAllResumes = async (req, res) => {
  try {
    const all = readData();
    return res.json(all);
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
};

export const getSuggestions = async (req, res) => {
  try {
    const { summary = '', skills = '', experience = '' } = req.body;
    const suggestions = [];
    if (summary.length < 40) suggestions.push('Make your summary longer: include your job title and 2–3 accomplishments.');
    else suggestions.push('Good summary length — consider adding metrics (e.g., "increased X by 20%").');
    if (skills.split(',').filter(s => s.trim()).length < 4) suggestions.push('Add more skills (technical + soft skills), separate by commas.');
    else suggestions.push('Skills list looks solid — group them by category (languages, tools, soft skills).');
    if (experience.length < 50) suggestions.push('Expand your experience: list achievements, not just duties.');
    else suggestions.push('Good experience content — try quantifying results with numbers or outcomes.');
    suggestions.push('Use action verbs (Designed, Implemented, Improved) to start bullet points.');
    suggestions.push('Keep resume length to 1 page if you are early-career; use concise bullets.');
    const improvedSummary = summary
      ? (summary.length > 120 ? summary : `Experienced developer — ${summary} (focus: deliver results using JS & React).`)
      : 'Experienced developer with a focus on building user-friendly web applications using modern JavaScript frameworks.';
    return res.json({ suggestions, improvedSummary });
  } catch (err) {
    return res.status(500).json({ error: err.message });
  }
};
