import express from 'express';
import { saveResume, getAllResumes, getSuggestions } from '../controllers/resumeController.js';
const router = express.Router();

router.post('/save', saveResume);
router.get('/all', getAllResumes);
router.post('/suggest', getSuggestions);

export default router;
