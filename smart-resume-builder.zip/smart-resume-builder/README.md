Smart Resume Builder - Ready to run (mocked AI, local JSON storage)
--------------------------------------------------------------------
What is inside:
- backend/  -> Node + Express API (saves resumes to local resumes.json; mocked AI suggestions)
- frontend/ -> Vite + React app (modern colorful UI), export PDF, preview, save locally via backend
- start-all: Run both frontend and backend together (after installing dependencies)

Quick start (step-by-step):
1. Open terminal in this folder.
2. Install root dev tool:
   npm install
3. Install backend dependencies:
   cd backend
   npm install
   cd ..
4. Install frontend dependencies:
   cd frontend
   npm install
   cd ..
5. Start both servers (in root):
   npm run start-all
   - Backend -> http://localhost:5000
   - Frontend -> http://localhost:5173

Notes:
- This build uses MOCKED AI suggestions (no OpenAI key required). If you have an OpenAI key and want to enable real AI,
  edit backend/controllers/resumeController.js and replace the mock block with an actual OpenAI call.
- Resumes are saved to backend/resumes.json (local file).
- Export PDF uses react-to-print and the browser print dialog.

Author: Generated for Arpita (virtual internship)
