import React, { useState } from 'react';
import axios from 'axios';

export default function ResumeForm({ data, setData, setSuggestions }){
  const [loading, setLoading] = useState(false);

  const change = (e) => setData(prev => ({ ...prev, [e.target.name]: e.target.value }));

  const askAI = async () => {
    setLoading(true);
    try {
      const res = await axios.post('http://localhost:5000/api/resume/suggest', {
        summary: data.summary, skills: data.skills, experience: data.experience
      });
      setSuggestions(res.data);
    } catch (e) {
      setSuggestions({ error: 'Failed to get suggestions' });
    } finally { setLoading(false); }
  };

  const save = async () => {
    try {
      await axios.post('http://localhost:5000/api/resume/save', data);
      alert('Saved locally!');
    } catch (e) {
      alert('Failed to save');
    }
  };

  return (
    <div>
      <h3 style={{marginBottom:8}}>Enter details</h3>
      <input className="form-input" name="name" value={data.name} onChange={change} placeholder="Full name" />
      <div style={{height:8}} />
      <input className="form-input" name="email" value={data.email} onChange={change} placeholder="Email" />
      <div style={{height:8}} />
      <input className="form-input" name="phone" value={data.phone} onChange={change} placeholder="Phone" />
      <div style={{height:8}} />
      <textarea className="form-text" name="summary" value={data.summary} onChange={change} placeholder="Professional summary (1-3 lines)"></textarea>
      <div style={{height:8}} />
      <textarea className="form-text" name="experience" value={data.experience} onChange={change} placeholder="Experience (bullets or paragraph)"></textarea>
      <div style={{height:8}} />
      <textarea className="form-text" name="education" value={data.education} onChange={change} placeholder="Education"></textarea>
      <div style={{height:8}} />
      <input className="form-input" name="skills" value={data.skills} onChange={change} placeholder="Skills (comma separated)" />
      <div className="actions">
        <button className="btn" onClick={askAI} disabled={loading}>{loading ? 'Thinking...' : 'Get AI Suggestions'}</button>
        <button className="btn" onClick={save} style={{background:'transparent', border:'1px solid rgba(255,255,255,0.06)'}}>Save</button>
      </div>
    </div>
  );
}
