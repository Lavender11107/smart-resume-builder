import React from 'react';

export default function AITips({ suggestions }){
  if (!suggestions) return null;
  if (suggestions.error) return <div className="card suggestions">Error: {suggestions.error}</div>;

  return (
    <div className="card suggestions">
      <h4 style={{marginTop:0}}>AI Suggestions</h4>
      <ol style={{paddingLeft:18}}>
        {suggestions.suggestions && suggestions.suggestions.map((s,i)=>(<li key={i} className="small" style={{marginBottom:6}}>{s}</li>))}
      </ol>
      {suggestions.improvedSummary && (
        <>
          <h5 style={{marginBottom:6}}>Improved summary</h5>
          <div className="small" style={{fontStyle:'italic'}}>{suggestions.improvedSummary}</div>
        </>
      )}
    </div>
  );
}
