import React, { useRef, useState } from 'react';
import ResumeForm from '../components/ResumeForm';
import ResumePreview from '../components/ResumePreview';
import AITips from '../components/AITips';
import { useReactToPrint } from 'react-to-print';

export default function Builder(){
  const [data, setData] = useState({
    name:'', email:'', phone:'', summary:'', education:'', experience:'', skills:''
  });
  const [suggestions, setSuggestions] = useState(null);
  const previewRef = useRef();

  const handlePrint = useReactToPrint({ content: ()=> previewRef.current });

  return (
    <div className="container">
      <div className="header">
        <div className="logo">Smart Resume Builder</div>
        <div><button className="btn" onClick={handlePrint}>Export PDF</button></div>
      </div>

      <div className="grid">
        <div className="card">
          <ResumeForm data={data} setData={setData} setSuggestions={setSuggestions} />
        </div>

        <div>
          <div className="card" ref={previewRef}>
            <ResumePreview data={data} />
          </div>

          <div style={{marginTop:12}}>
            <AITips suggestions={suggestions} />
          </div>
        </div>
      </div>

    </div>
  );
}
