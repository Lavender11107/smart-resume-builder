import React from 'react';
import { Link } from 'react-router-dom';
export default function Home(){
  return (
    <div className="container">
      <div className="header">
        <div className="logo">Smart Resume Builder</div>
        <div><Link to="/builder" className="btn">Start Building</Link></div>
      </div>

      <div className="card" style={{marginBottom:20}}>
        <h2>Welcome 👋</h2>
        <p className="small">Create a modern resume, get AI suggestions and export it as a PDF. This version uses mocked AI tips so you can run without an API key.</p>
      </div>
      <div className="card">
        <h3>How to use</h3>
        <ol>
          <li>Click "Start Building"</li>
          <li>Fill your details and click "Get AI Suggestions"</li>
          <li>Preview and click "Export PDF" to download</li>
        </ol>
      </div>

      <div className="footer">Made for Arpita — ready to run project for your virtual internship</div>
    </div>
  );
}
